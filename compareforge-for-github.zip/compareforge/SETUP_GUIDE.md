# 🚀 Инструкция по настройке GitHub + автоматический деплой

## Шаг 1: Создайте GitHub аккаунт (если нет)

1. Откройте на телефоне: https://github.com/signup
2. Введите email, придумайте пароль
3. Подтвердите email
4. Готово! ✅

---

## Шаг 2: Создайте новый репозиторий

1. Откройте: https://github.com/new
2. Заполните:
   - **Repository name**: `compareforge`
   - **Description**: `Comparison website for products and services`
   - Выберите **Public** (бесплатно)
   - **НЕ ставьте** галочки на README, .gitignore, license
3. Нажмите **Create repository**
4. **Скопируйте URL** который появится (выглядит как: `https://github.com/ваш-username/compareforge.git`)

---

## Шаг 3: Загрузите файлы на GitHub

### Вариант А: Через веб-интерфейс (проще для телефона)

1. На странице вашего репозитория нажмите **uploading an existing file**
2. Скачайте архив, который я дам ниже
3. Распакуйте его
4. Перетащите **ВСЕ файлы и папки** в окно GitHub
5. Внизу нажмите **Commit changes**
6. Подождите 1-2 минуты, пока файлы загрузятся

### Вариант Б: Через командную строку (если есть компьютер)

```bash
cd compareforge
git remote add origin https://github.com/ваш-username/compareforge.git
git branch -M main
git push -u origin main
```

---

## Шаг 4: Подключите Vercel для автодеплоя

### 4.1 Регистрация в Vercel

1. Откройте: https://vercel.com/signup
2. Нажмите **Continue with GitHub**
3. Разрешите Vercel доступ к GitHub
4. Готово! ✅

### 4.2 Импорт проекта

1. На главной странице Vercel нажмите **Add New... → Project**
2. Найдите репозиторий `compareforge`
3. Нажмите **Import**

### 4.3 Настройка проекта

**Framework Preset**: Vite
**Root Directory**: `./` (оставьте как есть)

**Build and Output Settings**:
- **Build Command**: `cd client && npm run build`
- **Output Directory**: `client/dist`
- **Install Command**: `cd client && npm install`

4. Нажмите **Deploy**
5. Подождите 2-3 минуты
6. Готово! Ваш сайт опубликован! 🎉

### 4.4 Подключите свой домен

1. В Vercel откройте ваш проект
2. Перейдите в **Settings → Domains**
3. Добавьте `compareforge.com`
4. Vercel покажет DNS записи, которые нужно добавить
5. Зайдите в панель управления вашего домена
6. Добавьте DNS записи:
   - **Type**: A
   - **Name**: @
   - **Value**: `76.76.21.21` (IP Vercel)
   
   И:
   - **Type**: CNAME
   - **Name**: www
   - **Value**: `cname.vercel-dns.com`

7. Подождите 10-30 минут
8. Сайт будет доступен на compareforge.com! ✅

---

## Шаг 5: Установите GitHub Mobile (для редактирования)

### На Android:
https://play.google.com/store/apps/details?id=com.github.android

### На iOS:
https://apps.apple.com/app/github/id1477376905

### После установки:

1. Войдите в свой GitHub аккаунт
2. Откройте репозиторий `compareforge`
3. Готово! Теперь можете редактировать файлы

---

## 📝 Как редактировать сайт с телефона

### Изменить цены, тексты, названия:

1. Откройте GitHub Mobile app
2. Найдите репозиторий `compareforge`
3. Перейдите в: `client` → `src` → `pages` → `Home.tsx`
4. Нажмите на **три точки** (⋯) → **Edit file**
5. Измените нужный текст (например, цену `$2.95` на `$4.95`)
6. Внизу нажмите **Commit changes**
7. Напишите описание изменения (например: "Updated Bluehost price")
8. Нажмите **Commit**

**Через 1-2 минуты сайт автоматически обновится!** 🎉

---

## 🎨 Примеры редактирования

### Изменить цену:

**Найдите:**
```tsx
<td className="py-4 px-4 font-semibold text-blue-600">$2.95</td>
```

**Измените на:**
```tsx
<td className="py-4 px-4 font-semibold text-blue-600">$4.95</td>
```

### Изменить название продукта:

**Найдите:**
```tsx
<span className="font-medium">Bluehost</span>
```

**Измените на:**
```tsx
<span className="font-medium">HostGator</span>
```

### Добавить партнерскую ссылку:

**Найдите:**
```tsx
<Button size="sm" className="bg-blue-600 hover:bg-blue-700">
  View Deal
</Button>
```

**Измените на:**
```tsx
<Button size="sm" className="bg-blue-600 hover:bg-blue-700" asChild>
  <a 
    href="https://www.bluehost.com/track/your-affiliate-id" 
    target="_blank" 
    rel="noopener noreferrer nofollow"
  >
    View Deal
  </a>
</Button>
```

---

## ✅ Что вы получите:

1. **Полный контроль** - редактируйте когда хотите
2. **Автоматический деплой** - изменения публикуются за 1-2 минуты
3. **Редактирование с телефона** - через GitHub Mobile app
4. **Бесплатный хостинг** - Vercel бесплатен для личных проектов
5. **SSL сертификат** - HTTPS автоматически
6. **История изменений** - можно откатить любое изменение

---

## 🆘 Если что-то не получается:

1. **Проблемы с деплоем?** 
   - Проверьте Build Logs в Vercel
   - Убедитесь, что указали правильные пути

2. **Сайт не обновляется?**
   - Подождите 2-3 минуты
   - Очистите кэш браузера (Ctrl+F5)

3. **Ошибка при редактировании?**
   - Убедитесь, что не удалили важные символы (скобки, кавычки)
   - Можно откатить изменение через GitHub

---

## 📚 Полезные ссылки:

- **GitHub**: https://github.com/
- **Vercel**: https://vercel.com/
- **GitHub Mobile**: https://github.com/mobile
- **Документация Vercel**: https://vercel.com/docs

---

## 🎯 Следующие шаги после настройки:

1. Зарегистрируйтесь в партнерских программах
2. Добавьте свои affiliate ссылки
3. Создайте больше сравнений
4. Настройте Google Analytics
5. Начните продвигать сайт!

Удачи! 🚀

