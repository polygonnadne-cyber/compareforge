# CompareForge - Сайт сравнений для заработка

## 🎯 О проекте

CompareForge - это профессиональный сайт для сравнения товаров, услуг и технологий, оптимизированный для монетизации через партнерские программы.

**Особенности**:
- ✅ Полностью адаптивный дизайн (отлично работает на телефонах)
- ✅ Готовые сравнительные таблицы
- ✅ SEO-оптимизация
- ✅ Легко редактировать с телефона
- ✅ Интеграция с партнерскими программами

## 🚀 Быстрый старт

### Локальная разработка

```bash
# Установка зависимостей
cd client
npm install

# Запуск dev сервера
npm run dev

# Открыть http://localhost:3000
```

### Сборка для продакшена

```bash
cd client
npm run build
# Файлы будут в папке dist/
```

## 📱 Редактирование с телефона

### Способ 1: GitHub Mobile (Рекомендуется)

1. Создайте репозиторий на GitHub
2. Загрузите файлы проекта
3. Установите GitHub Mobile app
4. Редактируйте файлы прямо в приложении
5. Подключите автодеплой на Vercel/Netlify

### Способ 2: Онлайн редакторы

**Replit** (https://replit.com):
- Импортируйте проект из GitHub
- Редактируйте в браузере телефона
- Мгновенный preview

**CodeSandbox** (https://codesandbox.io):
- Отличный мобильный интерфейс
- Поддержка React
- Легко делиться

### Способ 3: Мобильные приложения

**Android**:
- Spck Editor - полноценная IDE
- Acode - легкий редактор кода

**iOS**:
- Textastic - профессиональный редактор
- Buffer Editor - Git интеграция

## 📝 Как добавить новое сравнение

### 1. Откройте файл Home.tsx

Путь: `client/src/pages/Home.tsx`

### 2. Найдите секцию "Featured Comparisons"

### 3. Скопируйте блок Card и измените:

```tsx
<Card className="mb-8 overflow-hidden">
  <CardHeader className="bg-gradient-to-r from-blue-50 to-indigo-50">
    <CardTitle className="text-2xl">Название сравнения</CardTitle>
    <CardDescription>Описание</CardDescription>
  </CardHeader>
  <CardContent className="p-6">
    {/* Ваша таблица сравнения */}
  </CardContent>
</Card>
```

### 4. Добавьте партнерские ссылки

```tsx
<Button size="sm" asChild>
  <a 
    href="https://your-affiliate-link.com" 
    target="_blank" 
    rel="noopener noreferrer nofollow"
  >
    View Deal
  </a>
</Button>
```

## 💰 Монетизация

### Партнерские программы

**Amazon Associates**:
- Комиссия: 1-10%
- Регистрация: https://affiliate-program.amazon.com/

**Bluehost** (Хостинг):
- Комиссия: $65-$100 за продажу
- https://www.bluehost.com/affiliates

**NordVPN**:
- Комиссия: $30-$100
- Высокий спрос

**Shopify**:
- Комиссия: до $150
- https://www.shopify.com/affiliates

### Google AdSense

Добавьте код в `client/public/index.html`:

```html
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-YOUR-ID"
     crossorigin="anonymous"></script>
```

## 🌐 Деплой сайта

### Netlify (Самый простой)

1. Зайдите на https://www.netlify.com/
2. "Add new site" → "Deploy manually"
3. Загрузите папку `client/dist`
4. Подключите домен compareforge.com

### Vercel (Автоматический)

1. https://vercel.com/
2. Подключите GitHub репозиторий
3. Vercel автоматически настроит всё
4. Добавьте домен

### Cloudflare Pages

1. https://pages.cloudflare.com/
2. Подключите Git
3. Build: `cd client && npm run build`
4. Output: `client/dist`

## 📊 Структура проекта

```
compareforge/
├── client/                 # Frontend приложение
│   ├── src/
│   │   ├── pages/         # Страницы сайта
│   │   │   └── Home.tsx   # Главная страница (РЕДАКТИРУЙТЕ ЗДЕСЬ)
│   │   ├── components/    # UI компоненты
│   │   └── App.tsx        # Главный компонент
│   ├── public/            # Статичные файлы
│   └── dist/              # Собранный сайт (для деплоя)
├── MONETIZATION_GUIDE.md  # Подробное руководство по заработку
└── README_RU.md           # Этот файл
```

## 🎨 Кастомизация

### Изменить цвета

Откройте `client/src/index.css` и измените CSS переменные:

```css
:root {
  --primary: 217 91% 60%;    /* Синий */
  --secondary: 222 47% 11%;  /* Темно-серый */
}
```

### Изменить логотип

1. Замените иконку в компоненте Header
2. Или добавьте свой логотип в `client/public/`
3. Используйте: `<img src="/logo.png" alt="CompareForge" />`

### Добавить новую категорию

В секции "Browse by Category" добавьте:

```tsx
{ name: "Ваша категория", count: "X comparisons", color: "blue" }
```

## 📈 SEO оптимизация

### 1. Мета-теги

В `client/public/index.html`:

```html
<meta name="description" content="Compare top products and services">
<meta name="keywords" content="comparison, reviews, best deals">
```

### 2. Sitemap

Создайте `client/public/sitemap.xml`:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>https://compareforge.com/</loc>
    <changefreq>weekly</changefreq>
  </url>
</urlset>
```

### 3. Google Search Console

1. https://search.google.com/search-console
2. Добавьте свой домен
3. Отправьте sitemap

## 💡 Советы по заработку

### Первый месяц:
- Зарегистрируйтесь в Amazon Associates
- Добавьте 5-10 сравнений
- Настройте Google Analytics
- Начните SEO оптимизацию

### Первые 3 месяца:
- Добавляйте 2-3 новых сравнения в неделю
- Обновляйте цены регулярно
- Добавьте Google AdSense
- Ожидаемый доход: $50-$200/месяц

### Первый год:
- 20-30 категорий сравнений
- Прямые партнерства с брендами
- 2000-5000 посетителей/день
- Ожидаемый доход: $1000-$5000/месяц

## 🔧 Частые вопросы

**Q: Как часто обновлять цены?**
A: Минимум раз в неделю. Добавьте дату "Last updated" для доверия.

**Q: Сколько сравнений нужно для старта?**
A: Начните с 5-10 качественных сравнений в 2-3 категориях.

**Q: Когда ждать первых денег?**
A: Первые комиссии обычно приходят через 2-3 месяца после запуска.

**Q: Нужно ли покупать все товары для обзора?**
A: Нет. Используйте информацию от производителей, отзывы пользователей, и честно указывайте источники.

**Q: Как редактировать с телефона?**
A: Используйте GitHub Mobile или онлайн редакторы (Replit, CodeSandbox).

## 📚 Полезные ресурсы

**Партнерские сети**:
- Amazon Associates
- ShareASale
- CJ Affiliate
- ClickBank

**Обучение**:
- Authority Hacker
- Income School
- r/Affiliatemarketing

**Инструменты**:
- Google Analytics
- Google Search Console
- Ubersuggest (SEO)

## ⚠️ Важно

1. **Раскрытие партнерских отношений** - уже добавлено в футер
2. **Политика конфиденциальности** - создайте на https://www.privacypolicygenerator.info/
3. **Честные обзоры** - не обманывайте пользователей ради комиссий

## 🎉 Готово к запуску!

Ваш сайт полностью готов к монетизации. Следуйте инструкциям в `MONETIZATION_GUIDE.md` для детального плана действий.

**Следующие шаги**:
1. Зарегистрируйтесь в партнерских программах
2. Добавьте свои affiliate ссылки
3. Задеплойте на Netlify/Vercel
4. Подключите домен compareforge.com
5. Начните создавать контент

Удачи! 🚀

---

**Поддержка**: Если нужна помощь, создайте issue в GitHub или обратитесь к документации партнерских программ.

