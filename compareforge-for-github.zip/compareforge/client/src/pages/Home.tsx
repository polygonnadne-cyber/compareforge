import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Check, Star, TrendingUp, Zap, Shield, DollarSign } from "lucide-react";

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-lg flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-white" />
              </div>
              <span className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                CompareForge
              </span>
            </div>
            <nav className="hidden md:flex items-center gap-6">
              <a href="#comparisons" className="text-slate-600 hover:text-blue-600 transition-colors">Comparisons</a>
              <a href="#categories" className="text-slate-600 hover:text-blue-600 transition-colors">Categories</a>
              <a href="#about" className="text-slate-600 hover:text-blue-600 transition-colors">About</a>
            </nav>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-16 md:py-24">
        <div className="max-w-4xl mx-auto text-center">
          <Badge className="mb-4 bg-blue-100 text-blue-700 hover:bg-blue-200">
            Smart Comparison Platform
          </Badge>
          <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-slate-900 via-blue-800 to-indigo-900 bg-clip-text text-transparent">
            Make Smarter Decisions with Expert Comparisons
          </h1>
          <p className="text-xl text-slate-600 mb-8 max-w-2xl mx-auto">
            Compare top products, services, and technologies side-by-side. Save time and money with our detailed analysis and expert recommendations.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700">
              Explore Comparisons
            </Button>
            <Button size="lg" variant="outline">
              View Categories
            </Button>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="container mx-auto px-4 py-16">
        <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          <Card className="border-2 hover:border-blue-200 transition-all hover:shadow-lg">
            <CardHeader>
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                <Zap className="w-6 h-6 text-blue-600" />
              </div>
              <CardTitle>Fast Comparisons</CardTitle>
              <CardDescription>
                Get instant side-by-side comparisons of features, prices, and specifications
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="border-2 hover:border-indigo-200 transition-all hover:shadow-lg">
            <CardHeader>
              <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center mb-4">
                <Shield className="w-6 h-6 text-indigo-600" />
              </div>
              <CardTitle>Expert Reviews</CardTitle>
              <CardDescription>
                Unbiased analysis from industry experts to help you make informed decisions
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="border-2 hover:border-purple-200 transition-all hover:shadow-lg">
            <CardHeader>
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
                <DollarSign className="w-6 h-6 text-purple-600" />
              </div>
              <CardTitle>Best Deals</CardTitle>
              <CardDescription>
                Find the best prices and exclusive deals from trusted retailers
              </CardDescription>
            </CardHeader>
          </Card>
        </div>
      </section>

      {/* Featured Comparisons */}
      <section id="comparisons" className="container mx-auto px-4 py-16 bg-white/50 rounded-3xl my-8">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
            Featured Comparisons
          </h2>

          {/* Comparison Example 1: Web Hosting */}
          <Card className="mb-8 overflow-hidden">
            <CardHeader className="bg-gradient-to-r from-blue-50 to-indigo-50">
              <CardTitle className="text-2xl">Best Web Hosting Services 2025</CardTitle>
              <CardDescription>Compare top hosting providers for your website</CardDescription>
            </CardHeader>
            <CardContent className="p-6">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-4 px-4 font-semibold">Provider</th>
                      <th className="text-left py-4 px-4 font-semibold">Price/mo</th>
                      <th className="text-left py-4 px-4 font-semibold">Storage</th>
                      <th className="text-left py-4 px-4 font-semibold">Rating</th>
                      <th className="text-left py-4 px-4 font-semibold"></th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-b hover:bg-slate-50">
                      <td className="py-4 px-4">
                        <div className="flex items-center gap-2">
                          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                            Best Choice
                          </Badge>
                          <span className="font-medium">Bluehost</span>
                        </div>
                      </td>
                      <td className="py-4 px-4 font-semibold text-blue-600">$2.95</td>
                      <td className="py-4 px-4">50 GB SSD</td>
                      <td className="py-4 px-4">
                        <div className="flex items-center gap-1">
                          <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                          <span className="font-medium">4.8</span>
                        </div>
                      </td>
                      <td className="py-4 px-4">
                        <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                          View Deal
                        </Button>
                      </td>
                    </tr>
                    <tr className="border-b hover:bg-slate-50">
                      <td className="py-4 px-4">
                        <span className="font-medium">HostGator</span>
                      </td>
                      <td className="py-4 px-4 font-semibold text-blue-600">$3.75</td>
                      <td className="py-4 px-4">Unlimited</td>
                      <td className="py-4 px-4">
                        <div className="flex items-center gap-1">
                          <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                          <span className="font-medium">4.6</span>
                        </div>
                      </td>
                      <td className="py-4 px-4">
                        <Button size="sm" variant="outline">
                          View Deal
                        </Button>
                      </td>
                    </tr>
                    <tr className="hover:bg-slate-50">
                      <td className="py-4 px-4">
                        <span className="font-medium">SiteGround</span>
                      </td>
                      <td className="py-4 px-4 font-semibold text-blue-600">$3.99</td>
                      <td className="py-4 px-4">10 GB SSD</td>
                      <td className="py-4 px-4">
                        <div className="flex items-center gap-1">
                          <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                          <span className="font-medium">4.7</span>
                        </div>
                      </td>
                      <td className="py-4 px-4">
                        <Button size="sm" variant="outline">
                          View Deal
                        </Button>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <div className="mt-6 p-4 bg-blue-50 rounded-lg">
                <h4 className="font-semibold mb-2 flex items-center gap-2">
                  <Check className="w-5 h-5 text-blue-600" />
                  Our Recommendation
                </h4>
                <p className="text-sm text-slate-700">
                  <strong>Bluehost</strong> offers the best value for beginners with excellent uptime, 
                  free domain, and 24/7 support. Perfect for WordPress sites and small businesses.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Comparison Example 2: VPN Services */}
          <Card className="mb-8 overflow-hidden">
            <CardHeader className="bg-gradient-to-r from-indigo-50 to-purple-50">
              <CardTitle className="text-2xl">Top VPN Services Comparison</CardTitle>
              <CardDescription>Secure your online privacy with the best VPN providers</CardDescription>
            </CardHeader>
            <CardContent className="p-6">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-4 px-4 font-semibold">Service</th>
                      <th className="text-left py-4 px-4 font-semibold">Price/mo</th>
                      <th className="text-left py-4 px-4 font-semibold">Servers</th>
                      <th className="text-left py-4 px-4 font-semibold">Speed</th>
                      <th className="text-left py-4 px-4 font-semibold"></th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-b hover:bg-slate-50">
                      <td className="py-4 px-4">
                        <div className="flex items-center gap-2">
                          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                            Fastest
                          </Badge>
                          <span className="font-medium">NordVPN</span>
                        </div>
                      </td>
                      <td className="py-4 px-4 font-semibold text-indigo-600">$3.99</td>
                      <td className="py-4 px-4">5,500+</td>
                      <td className="py-4 px-4">
                        <Badge className="bg-green-100 text-green-700">Excellent</Badge>
                      </td>
                      <td className="py-4 px-4">
                        <Button size="sm" className="bg-indigo-600 hover:bg-indigo-700">
                          Get Deal
                        </Button>
                      </td>
                    </tr>
                    <tr className="border-b hover:bg-slate-50">
                      <td className="py-4 px-4">
                        <span className="font-medium">ExpressVPN</span>
                      </td>
                      <td className="py-4 px-4 font-semibold text-indigo-600">$6.67</td>
                      <td className="py-4 px-4">3,000+</td>
                      <td className="py-4 px-4">
                        <Badge className="bg-green-100 text-green-700">Excellent</Badge>
                      </td>
                      <td className="py-4 px-4">
                        <Button size="sm" variant="outline">
                          Get Deal
                        </Button>
                      </td>
                    </tr>
                    <tr className="hover:bg-slate-50">
                      <td className="py-4 px-4">
                        <div className="flex items-center gap-2">
                          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                            Best Value
                          </Badge>
                          <span className="font-medium">Surfshark</span>
                        </div>
                      </td>
                      <td className="py-4 px-4 font-semibold text-indigo-600">$2.49</td>
                      <td className="py-4 px-4">3,200+</td>
                      <td className="py-4 px-4">
                        <Badge className="bg-yellow-100 text-yellow-700">Very Good</Badge>
                      </td>
                      <td className="py-4 px-4">
                        <Button size="sm" variant="outline">
                          Get Deal
                        </Button>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Categories */}
      <section id="categories" className="container mx-auto px-4 py-16">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
            Browse by Category
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { name: "Web Hosting", count: "12 comparisons", color: "blue" },
              { name: "VPN Services", count: "8 comparisons", color: "indigo" },
              { name: "Cloud Storage", count: "10 comparisons", color: "purple" },
              { name: "Email Marketing", count: "15 comparisons", color: "pink" },
              { name: "E-commerce", count: "9 comparisons", color: "cyan" },
              { name: "Project Management", count: "11 comparisons", color: "green" },
              { name: "CRM Software", count: "7 comparisons", color: "orange" },
              { name: "Antivirus", count: "6 comparisons", color: "red" },
            ].map((category) => (
              <Card key={category.name} className="hover:shadow-lg transition-all cursor-pointer group">
                <CardHeader>
                  <CardTitle className="text-lg group-hover:text-blue-600 transition-colors">
                    {category.name}
                  </CardTitle>
                  <CardDescription>{category.count}</CardDescription>
                </CardHeader>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="container mx-auto px-4 py-16">
        <div className="max-w-4xl mx-auto bg-gradient-to-r from-blue-600 to-indigo-600 rounded-3xl p-12 text-center text-white">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Ready to Make Better Decisions?
          </h2>
          <p className="text-xl mb-8 text-blue-100">
            Join thousands of smart shoppers who save time and money with CompareForge
          </p>
          <Button size="lg" variant="secondary" className="bg-white text-blue-600 hover:bg-blue-50">
            Start Comparing Now
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t bg-white mt-16">
        <div className="container mx-auto px-4 py-12">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-lg flex items-center justify-center">
                  <TrendingUp className="w-5 h-5 text-white" />
                </div>
                <span className="text-xl font-bold">CompareForge</span>
              </div>
              <p className="text-sm text-slate-600">
                Making smart decisions easier with expert comparisons and unbiased reviews.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Categories</h4>
              <ul className="space-y-2 text-sm text-slate-600">
                <li><a href="#" className="hover:text-blue-600">Web Hosting</a></li>
                <li><a href="#" className="hover:text-blue-600">VPN Services</a></li>
                <li><a href="#" className="hover:text-blue-600">Cloud Storage</a></li>
                <li><a href="#" className="hover:text-blue-600">Software</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-sm text-slate-600">
                <li><a href="#" className="hover:text-blue-600">About Us</a></li>
                <li><a href="#" className="hover:text-blue-600">Contact</a></li>
                <li><a href="#" className="hover:text-blue-600">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-blue-600">Terms of Service</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Disclosure</h4>
              <p className="text-sm text-slate-600">
                CompareForge may earn affiliate commissions from purchases made through links on our site. 
                This helps us provide free comparisons to our users.
              </p>
            </div>
          </div>
          <div className="border-t mt-8 pt-8 text-center text-sm text-slate-600">
            <p>© 2025 CompareForge. All rights reserved.</p>
            <p className="mt-2">Last updated: October 20, 2025</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

